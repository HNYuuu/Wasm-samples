#ifndef _BARCODE_H
#define _BARCODE_H
#include "pnm.h"

/*
     detect barcode and add a string to the box (obj-pointer)
*/

int detect_barcode(job_t *job);

#endif
