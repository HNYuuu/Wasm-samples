#!/bin/bash

rm -rf build
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=Debug ..
make
cp ./src/libcollectc.a ../bug/
cd ../bug/
clang-9 -g test_cc_pqueue.c libcollectc.a -I./include -o test_cc_pqueue
cd ..
./bug/test_cc_pqueue