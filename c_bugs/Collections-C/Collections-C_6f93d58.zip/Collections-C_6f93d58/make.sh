#!/bin/bash

# source /home/eveneko/Workspace/emsdk/emsdk_env.sh
rm -rf build_wasm
mkdir build_wasm
cd build_wasm
emcmake cmake -DCMAKE_BUILD_TYPE=Debug ..
emmake make
cp ./src/libcollectc.a ../bug/
cd ../bug/
emcc -O0 -g -s INLINING_LIMIT=1 -s WASM=1 -I./include -o test_cc_pqueue.html test_cc_pqueue.c libcollectc.a
wasm2wat -o test_cc_pqueue.wat test_cc_pqueue.wasm
cd ..
# ./bug/test_cc_pqueue