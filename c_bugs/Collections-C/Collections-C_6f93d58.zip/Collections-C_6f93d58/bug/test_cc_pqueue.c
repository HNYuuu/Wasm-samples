#include <stdio.h>
#include "cc_pqueue.h"

struct cc_pqueue_s {
    size_t   size;
    size_t   capacity;
    float    exp_factor;
    void   **buffer;

    /* Memory management function pointers */
    void *(*mem_alloc)  (size_t size);
    void *(*mem_calloc) (size_t blocks, size_t size);
    void  (*mem_free)   (void *block);

    /*  Comparator function pointer, for compairing the elements of CC_PQueue */
    int   (*cmp) (const void *a, const void *b);
};

static int cmp(const void *a, const void *b)
{
    return *((int *)a) - *((int *)b);
}

int main(int argc, char **argv) {
    // Create a new array
    CC_PQueue *pq;

    cc_pqueue_new(&pq, cmp);

    int e = 1001, f = 1000;
    scanf("%d", &e);
    scanf("%d", &f);
    printf("e is %d\n", e);
    printf("f is %d\n", f);

    printf("before pushed 1, capacity: %d", (int)(pq->capacity));
    cc_pqueue_push(pq, (void *) &e);
    puts("after pushed 1");
    cc_pqueue_push(pq, (void *) &f);
    puts("after push 2");

    cc_pqueue_destroy(pq);
    puts("after destroy");

    return 0;
}